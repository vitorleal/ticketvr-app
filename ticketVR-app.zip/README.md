Ticket VR Chrome Plugin [![Build Status](https://travis-ci.org/vitorleal/ticketvr-chrome-extension.png?branch=master)](https://travis-ci.org/vitorleal/ticketvr-chrome-extension)
=======================

This is a Google Chrome plugin to check your Ticket VR/VA balance.
